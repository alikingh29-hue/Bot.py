
import discord
from discord.ext import commands
from discord import app_commands
import asyncio, time, os
from collections import defaultdict

TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = 1450297271332896821
BOT_OWNER_ID = 1133202019088355409

GUARD_ENABLED = True
SILENT_MODE = True

BAN_RETRY_COUNT = 3
BAN_RETRY_DELAY = 5

KICK_LIMIT = 2
BAN_LIMIT = 1
TIME_WINDOW = 8
LOCKDOWN_TIME = 180

WHITELIST_USERS = []
WHITELIST_ROLES = []
WHITELIST_BOTS  = []

ROLE_BACKUP = {}
CHANNEL_BACKUP = {}

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

kick_track = defaultdict(list)
ban_track = defaultdict(list)
lockdown_active = False

def now():
    return time.time()

def is_master(user, guild):
    if user.id in (BOT_OWNER_ID, guild.owner_id):
        return True
    if user.id in WHITELIST_USERS:
        return True
    m = guild.get_member(user.id)
    if m:
        for r in m.roles:
            if r.id in WHITELIST_ROLES:
                return True
    return False

async def alert_owner(guild, message):
    owner = guild.get_member(BOT_OWNER_ID)
    if owner:
        try:
            await owner.send(message)
            return
        except:
            pass
    if guild.owner:
        try:
            await guild.owner.send(message)
        except:
            pass

async def lockdown(guild):
    global lockdown_active
    if lockdown_active:
        return
    lockdown_active = True
    for ch in guild.channels:
        try:
            await ch.set_permissions(guild.default_role, send_messages=False, connect=False)
        except:
            pass
    await asyncio.sleep(LOCKDOWN_TIME)
    for ch in guild.channels:
        try:
            await ch.set_permissions(guild.default_role, send_messages=True, connect=True)
        except:
            pass
    lockdown_active = False

async def instant_ban(guild, user, reason):
    if not GUARD_ENABLED:
        return
    member = guild.get_member(user.id)
    if not member:
        return
    if not guild.me.guild_permissions.ban_members:
        return
    if member.top_role >= guild.me.top_role:
        return
    for _ in range(BAN_RETRY_COUNT):
        try:
            await guild.ban(member, reason=f"AX-GUARD: {reason}")
            return
        except:
            await asyncio.sleep(BAN_RETRY_DELAY)
    await lockdown(guild)

def backup_roles(guild):
    ROLE_BACKUP.clear()
    for r in guild.roles:
        if not r.is_default():
            ROLE_BACKUP[r.id] = r.permissions

def backup_channels(guild):
    CHANNEL_BACKUP.clear()
    for c in guild.channels:
        CHANNEL_BACKUP[c.id] = c.name

@bot.event
async def on_ready():
    guild = discord.Object(id=GUILD_ID)
    bot.tree.clear_commands(guild=guild)
    await bot.tree.sync(guild=guild)
    g = bot.get_guild(GUILD_ID)
    if g:
        backup_roles(g)
        backup_channels(g)
    print("🛡️ AX-GUARD ACTIVE")

@bot.event
async def on_member_join(member):
    if member.bot and member.id not in WHITELIST_BOTS:
        await instant_ban(member.guild, member, "Unauthorized Bot")

bot.run(TOKEN)
